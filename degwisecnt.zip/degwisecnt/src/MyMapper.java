import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;



public class MyMapper extends Mapper<MyKey, MyValue, Text, Text> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		String edu=inpK.getedu();
		int week=inpV.getAmt();
		
		
		c.write(new Text(inpK.getedu()), new Text(""+week+""));
		
		
	}

}