import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class reducer3 extends Reducer<Text,Text,Text,Text>{

	public void reduce(Text inpk ,Iterable<Text> inpv,Context c) throws IOException, InterruptedException
	{
		int total=0;
		for(Text x:inpv)
		{
		total++;
		}
		
		c.write(new Text("Employed female widowed and Divorced in the given age is-->"),new Text(total+""));
	}
}