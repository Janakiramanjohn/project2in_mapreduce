

import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper3 extends Mapper<LongWritable,Text,Text,Text>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		int min=c.getConfiguration().getInt("min", 0);
		int max=c.getConfiguration().getInt("max", 0);
		
		String[] eachVal = inpv.toString().split(",");
		String[] FirstVal = eachVal[0].split(" ");
		String age = FirstVal[1];
	  String[] fourthVal = eachVal[3].split(":");
		String gender = fourthVal[1];
		
	String[] secondVal = eachVal[2].split(":");
		String maritalstatus=secondVal[1];
		
		String[] nineval = eachVal[9].split("  ");
	     String check=nineval[1];
	     String[] check1=check.split("}");
	     int count=0;
		int weeks=Integer.parseInt(check1[0]);
		
		int age1=Integer.parseInt(age);
		
		if((age1>=min)&&(age1<=max))
		{		
		
		if(gender.equals(" \" Female\"")){
		if(weeks>0)
		{
			
			if((maritalstatus.equals(" \" Widowed\""))||(maritalstatus.equals(" \" Divorced\"")))
					{

	
					c.write(new Text("dummy"), new Text("1"));
					
					}
		}
					}
					}
			
					
		}
		
}
