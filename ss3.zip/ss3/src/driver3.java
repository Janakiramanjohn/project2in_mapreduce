
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class driver3 {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {

	Configuration c = new Configuration();
	
	Scanner s=new Scanner(System.in);
	try{
	System.out.println("Enter Min age");
	int min=s.nextInt();
	c.setInt("min", min);
	System.out.println("Enter Max age");
	int max=s.nextInt();
	c.setInt("max", max);
	if(max>=min)
	{
	
	Job j=new Job(c,"first program");
	j.setJarByClass(driver3.class);
	j.setMapperClass(mapper3.class);
	j.setReducerClass(reducer3.class);

	j.setNumReduceTasks(1);
	j.setMapOutputKeyClass(Text.class);
	j.setMapOutputValueClass(Text.class);
	FileInputFormat.addInputPath(j, new Path(args[0]));
	FileOutputFormat.setOutputPath(j, new Path(args[1]));
	System.exit(j.waitForCompletion(true)?0:1);
	}
	else
	{
		System.out.println("Please check the min and max values");
	}
	}
	catch(Exception e)
	{
		System.out.println("Pls enter valid values");
	}
	}
}
